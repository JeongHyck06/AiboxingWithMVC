MVCtest
|-.gitignore
|-README.md
|-app.js
|-controllers
| |-gameController.js
| |-mainController.js
|-db
| |-mongo.js
|-models
|-package-lock.json
|-package.json
|-public
| |-css
| | |-gameInterface.css
| | |-index.css
| | |-list.css
| |-js
| | |-gameInterface.js
| | |-index.js
| | |-list.js
|-views
| |-gameInterface.ejs
| |-index.ejs
| |-list.ejs

```

```
